import { SplitpipePipe } from './splitpipe.pipe';

describe('SplitpipePipe', () => {
  it('create an instance', () => {
    const pipe = new SplitpipePipe();
    expect(pipe).toBeTruthy();
  });
});
