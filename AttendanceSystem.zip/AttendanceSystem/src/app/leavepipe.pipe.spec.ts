import { LeavepipePipe } from './leavepipe.pipe';

describe('LeavepipePipe', () => {
  it('create an instance', () => {
    const pipe = new LeavepipePipe();
    expect(pipe).toBeTruthy();
  });
});
