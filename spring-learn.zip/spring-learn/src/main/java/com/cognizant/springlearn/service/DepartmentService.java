package com.cognizant.springlearn.service;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.springlearn.Department;
import com.cognizant.springlearn.SpringLearnApplication;
import com.cognizant.springlearn.dao.DepartmentDao;

@Service
public class DepartmentService {
	private static final Logger LOGGER = LogManager.getLogger(SpringLearnApplication.class);
	@Autowired 
	private DepartmentDao departmentDao;
	
	public ArrayList<Department> getAllDepartments()
	{
		LOGGER.info("Department Service");
		return departmentDao.getAllDepartments();
	}
}
