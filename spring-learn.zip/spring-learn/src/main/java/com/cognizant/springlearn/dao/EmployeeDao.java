package com.cognizant.springlearn.dao;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.Employee;
import com.cognizant.springlearn.SpringLearnApplication;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;

@Component
public class EmployeeDao {
	private static final Logger LOGGER = LogManager.getLogger(SpringLearnApplication.class);
	public static ArrayList<Employee> EMPLOYEE_LIST = new ArrayList<>();
	
	public EmployeeDao()
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		EMPLOYEE_LIST =  (ArrayList<Employee>) context.getBean("employeeList");
	}
	
	public ArrayList<Employee> getAllEmployees()
	{
		LOGGER.info("Employee Dao");
		return EMPLOYEE_LIST;
	}

	
}
